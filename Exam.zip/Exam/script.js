console.log("page loading...");

var pets = [3, 5, 8];
var spans = [
    document.querySelector("#pepper-pet"),
    document.querySelector("#bruce-pet"),
    document.querySelector("#oscar-pet")
];

function pet(id) {
    pets[id]++;
    spans[id].innerHTML = pets[id] + " petting(s)";
}

function hideButton(x) {
x.style.display = 'none';
}

function alert1(select) {
    alert ('You are looking for a:\n' + select.options[select.selectedIndex].text);
}